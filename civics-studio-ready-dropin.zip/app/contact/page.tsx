export default function ContactPage() {
  return (
    <div className="bg-white">
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="max-w-3xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-blue-700">
            Contact
          </p>

          <h1 className="mt-4 text-5xl font-bold tracking-tight text-slate-950">
            Contact Civics Studio
          </h1>

          <p className="mt-6 text-lg leading-8 text-slate-600">
            For questions, school use, club use, partnerships, or feedback, contact Civics Studio by email.
          </p>

          <div className="mt-10 rounded-3xl border border-slate-200 bg-slate-50 p-8">
            <h2 className="text-2xl font-bold text-slate-950">
              Email
            </h2>

            <a
              href="mailto:civicsstudio@gmail.com"
              className="mt-4 inline-block text-lg font-semibold text-blue-700 hover:text-blue-900"
            >
              civicsstudio@gmail.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
